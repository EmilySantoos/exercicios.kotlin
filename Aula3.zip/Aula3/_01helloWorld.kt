
fun main() {

    //println pula uma linha printa oque a gente quer
    /* print escreve tudo sem pular linha  */

    println("Hello  world")
    print(" world!")

}