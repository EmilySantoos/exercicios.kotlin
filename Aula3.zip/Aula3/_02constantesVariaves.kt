

    fun main(){
        val num1 = 3
        val num2 = 3.0

     //   num2 = 5.0

       var a: Int
       a =  10

        var b: Float = 10f

        println(a)
        println(b)
        println(a+b)
    }
