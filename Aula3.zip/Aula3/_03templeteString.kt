
fun main (){
    val nome = "Marcos"

    val saudacao = "Sejá bem vindo"


    //{} serve para juntar mais de uma variavel
    println("Olá $nome , ${saudacao + nome}")

    var a = 5
    var b = 10
    print("A soma de $a + $b = ${a + b}")
}