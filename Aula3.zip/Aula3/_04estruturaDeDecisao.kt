 fun main (){
    /*
     print("Digite seu nome:")
     var nome = readLine()

     if (nome == "Carla")
         println("Você a $nome")
     else if(nome == "Natasha")
         println("você A $nome")
     else if(nome == "Bianca")
         println("você A $nome")
     else if(nome == "Ninguem")
             println("você A $nome")
     else
         println("Nome inválido")

     */

     // {} no if para dois print na mesma linha

     println("Digite a média de aluno ")
     var media = 2
    if (media > 6) {
        println("Aprovado")
        println("Parabéns")
    }
     else if (media <= 2)
         println("Precisa fazer exame")
     else if (media < 2)
         println("Reprovado")
 }

