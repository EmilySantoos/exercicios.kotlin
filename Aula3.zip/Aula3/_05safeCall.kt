fun main (){
    var num = 5

    println(podeRetornaNulo(num))

    var semNada: Int?

    semNada = podeRetornaNulo(num)
    println(semNada)

}

 fun podeRetornaNulo(a: Int): Int?{
     if (a < 5) return  10 else return null
 }