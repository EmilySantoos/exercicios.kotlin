fun main (){

    println("Digite a nota do aluno :")
    val nota = readLine()?.toInt()

    when(nota){
        10,9,8 -> println("Parabens você é um aluno exemplar")
        7,6 -> println("Você não fez mais que obrigação")
        5,4,3 -> println("Ficou de exame cinderelou")
        2,1,0 -> println("Reprovao! sem chance")
        else -> println("Nota fora dos parametros")
    }
}