fun main (){
    //i in 1..10
    //vai inteira ate a primeira rodada
    //for igual a 5 avança uma casa no continue
    // i for igual a 7 vai para no 7 nao vai continua 
    for ( i in 1..10){
        if (i==5)
            continue
        else if (i == 7)
            break
        println("Atual $i")
    }
}